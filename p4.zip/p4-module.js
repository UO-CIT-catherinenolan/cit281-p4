/*
    CIT 281 Project 4
    Name: Catherine Nolan
*/
 
const {data} = require("./p4-data.js");

function getQuestions() {
    let arrStr = [];
    for (let d = 0; d < data.length; d++) {
        arrStr.push(data[d].question);
    }
    return arrStr;
}

function getAnswers () {
    let arrStr = [];
    for (let d = 0; d < data.length; d++) {
        arrStr.push(data[d].answer);
    }
    return arrStr;
}

function getQuestionsAnswers () {
    const clonedArr = [...data];
    return clonedArr;
}

function getQuestion (number = "") {
    let returnObj = {error: "", question: "", number: ""};
    if (isNaN(parseInt(number))) returnObj.error = "Question number must be an integer";
    else if (parseInt(number) < 1) rewturnObj.error = "Question number must be >= 1"; 
    else if (parseInt(number) > data.length) returnObj.error = `Question number must be less than the number of questions (${data.length})`; 
    else {
        returnObj.question = data[parseInt(numer)-1].question; 
        returnObj.number = parseInt(number);
    } 
    return returnObj; 
}

function getAnswer (number = "") {
    let returnObj = {error: " ", answer: " ", number: " "}; 
    if (isNaN(parseInt(number))) returnObj.error = "Answer number must be an integer"; 
    else if (parseInt(number) < 1) returnObj.error = "Answer number must be >= 1"; 
    else if (parseInt(number) > data.length) returnObj.error = `Answer number must be less than the number of questions (${data.length})`; 
    else {
        returnObj.answer = data[parseInt(number)-1].answer; 
        returnObj.number = parseInt(number); 
    }
    return returnObj; 
}

function getQuestionAnswer (number = "") {
    let returnObj = {error: " ", question: " ", number: " "}; 
    if (isNaN(parseInt(number))) returnObj.error = "Question number must be an integer"; 
    else if (parseInt(number) < 1) returnObj.error = "Question number must be >= 1"; 
    else if (parseInt(number) > data.length) returnObj.error = `Question number must be less than the number of questions and answers (${data.length})`; 
    else {
        returnObj.question = data[parseInt(number)-1].question; 
        returnObj.number = parseInt(number); 
        returnObj.answer = data[parseInt(number)- 1].answer;
    }
    return returnObj; 
}

//extra credit 
//POST
function addQuestionAnswer(info = {}){
    let returnObj = {error: "", message:"", number: -1};
    if(Object.keys(info).length > 0){
        if(!info.answer) returnObj.error =  "Object answer property required";
        else if(!info.question) returnObj.error =  "Object question property required";
        else
        {
            data.push(info);
            returnObj.number = Object.keys(data).length;
            returnObj.message = "Question added";
        }
    }
    else returnObj.error = "Object question property required";
    return returnObj;
}

//PUT
function updateQuestionAnswer(info = {}){
    let returnObj = {error: "", message: "", number: ""};
    if(Object.keys(info).length > 0){
        if(isNaN(parseInt(info.number))) returnObj.error = "Object number property must be a valid integer";
        else
        {
            data[info.number-1].question = info.question;
            data[info.number-1].answer = info.answer;
            returnObj.message = "Question " + info.number + " updated";
            returnObj.number = info.number;
        }
    }
    else returnObj.error = "Object question property or answer property required"
    return returnObj;
}

//DELETE
function deleteQuestionAnswer(number=""){
    let returnObj = {error: "", message: "", number: ""};
    if(isNaN(parseInt(number))) returnObj.error = "Question/answer number must be an integer";
    else if(parseInt(number) < 1) returnObj.error = "Question/answer number must be >= 1";
    else if (parseInt(number) > data.length) returnObj.error = `Question/answer number must be less than the number of questions(${data.length})`;
    else
    {
        data.splice(parseInt(number)-1,1);
        returnObj.message = "Question " + number + " deleted";
        returnObj.number = parseInt(number);
    }
    return returnObj;
}

/*****************************
  Module function testing
******************************/
function testing(category, ...args) {
    console.log(`\n** Testing ${category} **`);
    console.log("-------------------------------");
    for (const o of args) {
      console.log(`-> ${category}${o.d}:`);
      console.log(o.f);
    }
  }
  
  // Set a constant to true to test the appropriate function
  const testGetQs = false;
  const testGetAs = false;
  const testGetQsAs = false;
  const testGetQ = false;
  const testGetA = false;
  const testGetQA = false;
  const testAdd = false;      // Extra credit
  const testUpdate = false;   // Extra credit
  const testDelete = false;   // Extra credit

// getQuestions()
if (testGetQs) {
    testing("getQuestions", { d: "()", f: getQuestions() });
  }
  
  // getAnswers()
  if (testGetAs) {
    testing("getAnswers", { d: "()", f: getAnswers() });
  }
  
  // getQuestionsAnswers()
  if (testGetQsAs) {
    testing("getQuestionsAnswers", { d: "()", f: getQuestionsAnswers() });
  }
  
  // getQuestion()
  if (testGetQ) {
    testing(
      "getQuestion",
      { d: "()", f: getQuestion() },      // Extra credit: +1
      { d: "(0)", f: getQuestion(0) },    // Extra credit: +1
      { d: "(1)", f: getQuestion(1) },
      { d: "(4)", f: getQuestion(4) }     // Extra credit: +1
    );
  }
  
  // getAnswer()
  if (testGetA) {
    testing(
      "getAnswer",
      { d: "()", f: getAnswer() },        // Extra credit: +1
      { d: "(0)", f: getAnswer(0) },      // Extra credit: +1
      { d: "(1)", f: getAnswer(1) },
      { d: "(4)", f: getAnswer(4) }       // Extra credit: +1
    );
  }
  
  // getQuestionAnswer()
  if (testGetQA) {
    testing(
      "getQuestionAnswer",
      { d: "()", f: getQuestionAnswer() },    // Extra credit: +1
      { d: "(0)", f: getQuestionAnswer(0) },  // Extra credit: +1
      { d: "(1)", f: getQuestionAnswer(1) },
      { d: "(4)", f: getQuestionAnswer(4) }   // Extra credit: +1
    );
  }

  //extra credit
  //addQuestionAnswer
  if(testAdd){
    testing(
        "addQuestionAnswer",
        {d: "()", f: addQuestionAnswer()},
        {d: "({})", f: addQuestionAnswer({})},
        {d: '(question: "Q4")', f: addQuestionAnswer({question: "Q4"})},
        {d: '(answer: "A4")', f: addQuestionAnswer({answer: "A4"})},
        {d: '(question:"Q4", answer: "A4")', f: addQuestionAnswer({question: "Q4", answer:"A4"})}
    );
}


//updateQuestionAnswer ()
if(testUpdate){
    testing(
        "updateQuestionAnswer",
        {d: "()", f: updateQuestionAnswer()},
        {d: "({})", f: updateQuestionAnswer({})},
        {d: '(question: "Q1U")', f: updateQuestionAnswer({question: "Q1U"})},
        {d: '(answer: "A1U")', f: updateQuestionAnswer({answer: "A1U"})},
        {d: '(question:"Q1U", answer: "A1U")', f: updateQuestionAnswer({question: "Q1U", answer:"A1U"})},
        {d: '(number: 1, question:"Q1U", answer: "A1U")', f: updateQuestionAnswer({number: 1, question: "Q1U", answer:"A1U"})}
    );
    console.log(data);
}


//deleteQuestionAnswer
if(testDelete){
    testing(
        "deleteQuestionAnswer",
        { d: "()", f: deleteQuestionAnswer()},
        { d: "(0)", f: deleteQuestionAnswer(0)},
        { d: "(1)", f: deleteQuestionAnswer(1)},
        { d: "(4)", f: deleteQuestionAnswer(4)}
    )
    console.log(data);
}

module.exports = {
    getQuestions,
    getAnswers,
    getQuestionsAnswers,
    getQuestion,
    getAnswer,
    getQuestionAnswer,
    addQuestionAnswer,
    updateQuestionAnswer,
    deleteQuestionAnswer
};
