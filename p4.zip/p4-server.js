/* 
    CIT 281 Project 4
    Name: Catherine Nolan
*/ 

const fastify = require('fastify') (); 
const {getQuestions, getAnswers, getQuestionsAnswers, getQuestion,getAnswer,getQuestionAnswer,addQuestionAnswer, updateQuestionAnswer, deleteQuestionAnswer} = require('./p4-module.js');

//return all questions
fastify.get ("/cit/question", (request, reply) =>  {
    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {
                error: " ", 
                statusCode: 200, 
                question: getQuestions()
            });
}); 

//return all answers
fastify.get("/cit/answer", (request, reply) => {
    reply 
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {error: " ", 
            statusCode: 200, 
            answers: getAnswers()
        });
});

//return all questions and answers
fastify.get("/cit/questionanswer", (request, reply) => {
    reply 
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {
            error: " ", 
            statusCode: 200, 
            answers: getQuestionsAnswers()
        });
});

//return a specific question 
fastify.get ("/cit/question/:number", (request, reply) => {
    const {number} = request.params; 
    reply  
        .code(200)
        .header("Content-Type", "applicaation/json; charset=utf-8")
        .sed(
            {
                error: getQuestion(number).error, 
                statusCode: 200, 
                question: getQuestion(number).question, 
                number: getQuestion(number).number
            });
});

//return a specific answer
fastify.get ("/cit/question/:number", (request, reply) => {
    const {number} = request.params; 
    reply  
        .code(200)
        .header("Content-Type", "applicaation/json; charset=utf-8")
        .sed(
            {
                error: getAnswer(number).error, 
                statusCode: 200, 
                question: getAnswer(number).question, 
                number: getAnswer(number).number
            });
});

//return specific question and answer
fastify.get ("/cit/questionanswer/:number", (request, reply) => {
    const {number} = request.params; 
    reply  
        .code(200)
        .header("Content-Type", "applicaation/json; charset=utf-8")
        .sed(
            {
                error: getQuestionAnswer(number).error, 
                statusCode: 200, 
                question: getQuestionAnswer(number).question, 
                answer: getQuestionAnswer(number).answer,
                number: getQuestionAnswer(number).number
            });
});

//unmatched route handler
fastify.get("*", (request, reply) => {
    reply  
        .code(404)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {
                error: "Route not found", 
                statusCode: 404
            });
}); 

//extra credit
//POST
fastify.post("/cit/question",(request,reply) => {
    const {question, answer} = request.body;
    let d = addQuestionAnswer({question: question, answer:answer});

    reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8")
        .send(
            {
                error: d.error,
                statusCode: 201,
                number: d.number
            });
});

//PUT
fastify.put("/cit/question/:number",(request,reply) => {
    const { number } = request.params;
    const {question, answer} = request.body;
    let d = updateQuestionAnswer({number: number, question: question, answer:answer});
    reply
        .code(200)
        .header("Content-Type","application/json; charset=utf-8")
        .send(
            {
                error: d.error,
                statusCode: 200,
                number: d.number
            });
});

//DELETE
fastify.delete("/cit/question/:number",(request,reply) => {
    const { number } = request.params;
    let d = deleteQuestionAnswer(number);

    reply
        .code(200)
        .header("Content-Type","application/json; charset=utf-8")
        .send(
            {
                error: d.error,
                statusCode: 200,
                number: d.number
            });
});

const listenIP = "localhost";
const listenPort = 8082;
fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    
    console.log(`server listening on address ${address} port ${listenPort}`);
})